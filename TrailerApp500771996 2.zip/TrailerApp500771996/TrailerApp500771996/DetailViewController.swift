//
//  DetailViewController.swift
//  TrailerApp500771996
//
//  Created by Feliciano Babel on 15/04/2019.
//  Copyright © 2019 Feliciano Babel. All rights reserved.
//

import Foundation
import UIKit
import AVKit
import AVFoundation

class DetailViewController: UIViewController {
    
    @IBOutlet weak var stillImageView: UIImageView!
    
    @IBOutlet weak var genreLabel: UITextView!
    @IBOutlet weak var posterImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var genreTitle: UILabel!
    @IBOutlet weak var descriptionLabel: UITextView!
    
    var trailer: TrailerObject?
    
    @IBOutlet weak var watchTrailerButton: UIButton!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    var myImage: UIImage!
    
    override func viewDidLoad() {
        
        titleLabel.text = trailer?.title
        genreTitle.text = NSLocalizedString("Genre", comment: "")
        genreLabel.text = ""
        for number in 0..<((trailer?.genre.count)!){
            genreLabel.text = ((genreLabel.text! + " ") +  (trailer?.genre[number])! + ("\n"))
        }
        
        descriptionLabel.text = trailer?.description
        descriptionLabel.isEditable = false
        
        
        let imageURLStringStill = trailer?.stillImage
        let stillUrl = URL(string: imageURLStringStill ?? "")
        stillImageView.kf.setImage(with: stillUrl)
        
        let imageURLStringPoster = trailer?.posterImage
        let posterUrl = URL(string: imageURLStringPoster ?? "")
        posterImageView.kf.setImage(with: posterUrl)
        watchTrailerButton.setTitle(NSLocalizedString("Watch",comment: ""), for: .normal)
        watchTrailerButton.contentHorizontalAlignment = UIControl.ContentHorizontalAlignment.left

        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
        self.navigationController?.view.backgroundColor = .clear
        
    }
    @IBAction func isClicked(_ sender: Any) {
        let videoUrl = URL(string: (trailer?.url)!)
        let player = AVPlayer(url: videoUrl!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        
        present(playerViewController, animated: true){
            playerViewController.player?.play()
        }
    }
}

    

