//
//  TrailerObject.swift
//  TrailerApp500771996
//
//  Created by Feliciano Babel on 15/04/2019.
//  Copyright © 2019 Feliciano Babel. All rights reserved.
//

import Foundation
struct TrailerObject: Codable{
    let id: Int
    let title: String
    let url: String
    let posterImage: String
    let stillImage: String
    let genre: [String]
    let description: String

}
