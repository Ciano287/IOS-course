//
//  ViewController.swift
//  TrailerApp500771996
//
//  Created by Feliciano Babel on 15/04/2019.
//  Copyright © 2019 Feliciano Babel. All rights reserved.
//

import UIKit
import Alamofire
import Kingfisher

class ViewController: UIViewController {

    @IBOutlet weak var myTableView: UITableView!
    private var trailerArray: [TrailerObject]? {
        didSet {
            myTableView.reloadData()
        }
    }
    let refreshControl = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()

        title = NSLocalizedString("TrailerTitle", comment: "")
        navigationController?.navigationBar.prefersLargeTitles = true
        setupTableView()
        fetchTrailers()
        setupRefreshControl()
    }
    
    func setupTableView() {
        myTableView.register(UINib(nibName: "TableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell")
        myTableView.dataSource = self
        myTableView.delegate = self
    }
    
    func fetchTrailers() {
        Alamofire.request("https://appstubs.triple-it.nl/trailers/")
            .responseData(completionHandler: { [weak self] (response) in
                guard let jsonData = response.data else { return }
                let decoder = JSONDecoder()
                self?.trailerArray = try? decoder.decode([TrailerObject].self, from: jsonData)
            })
    }
    func setupRefreshControl(){
        myTableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refresh), for: .valueChanged)
    }
    
    @objc func refresh(){
        
        myTableView.reloadData()
        refreshControl.endRefreshing()
        
    }
    
    


}
extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return trailerArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        cell.trailer = trailerArray?[indexPath.row]
        print(cell)
        return cell
    }
}

extension ViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let detailVC = storyboard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        detailVC.trailer = trailerArray?[indexPath.row]
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
}
