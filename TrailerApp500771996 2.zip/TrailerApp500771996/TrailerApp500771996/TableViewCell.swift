//
//  TableViewCell.swift
//  TrailerApp500771996
//
//  Created by Feliciano Babel on 15/04/2019.
//  Copyright © 2019 Feliciano Babel. All rights reserved.
//

import Foundation
import UIKit

final class TableViewCell: UITableViewCell {
    

    
    @IBOutlet weak var stillImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UITextView!
    
    var trailer: TrailerObject? {
        didSet {
            titleLabel.text = trailer?.title
            descriptionLabel.text = trailer?.description
            descriptionLabel.isEditable = false
            
            if let imageURLString = trailer?.posterImage {
                let url = URL(string: imageURLString)
                stillImageView.kf.setImage(with: url)
            }
            
            
        }
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        titleLabel.text = nil
        descriptionLabel.text = nil
        stillImageView.image = nil
    }
}

